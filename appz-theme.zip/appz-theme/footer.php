<div class="container_12">
	<footer id="footer" class="grid_12">
		<p class="left"><?php echo theme_option('theme_copyright', __('&copy; 2013 Appz. All Rights Reserved.', TDOMAIN)); ?></p>

		<p class="right"><?php _e("Theme By", TDOMAIN); ?> <a href="http://www.themeshaker.com/">Themeshaker.com</a> <?php _e("and", TDOMAIN); ?> <a href="http://www.bestpsdfreebies.com/">Best PSD Freebies</a>.</p>
	</footer>
</div>

<?php wp_footer(); ?>
</body>
</html>